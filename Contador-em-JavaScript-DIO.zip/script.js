var currentNumberWrapper = document.getElementById("currentNumber");
var currentNumber = 0;

function increment(){
  currentNumber = currentNumber +1;
  currentNumberWrapper.innerHTML = currentNumber; 

  if(currentNumber > 10){
    document.getElementById("currentNumber").style.color = "green";
  }
    if(currentNumber <= 10 && currentNumber >= 0){
    document.getElementById("currentNumber").style.color = "black";
  }
}

function decrement(){
  currentNumber = currentNumber -1;
  currentNumberWrapper.innerHTML = currentNumber;

  if(currentNumber < 0){
    document.getElementById("currentNumber").style.color = "red";
  }
  if(currentNumber <= 10 && currentNumber >= 0){
    document.getElementById("currentNumber").style.color = "black";
  }
}