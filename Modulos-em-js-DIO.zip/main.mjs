import {mostraIdade, mostraCidade, mostraProfissao} from './funcoes.mjs';

console.log(mostraIdade('Wesley', 25));
console.log(mostraCidade('Wesley','Taboão da Serra'));
console.log(mostraProfissao('Wesley','desenvolvedor Java Full-Stack e professor de Jiu-Jitsu, Muay-Thai, Boxe, MMA e Defesa Pessoal'));

 