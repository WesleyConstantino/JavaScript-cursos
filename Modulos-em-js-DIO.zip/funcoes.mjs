function mostraIdade(nome, idade) {
  return `A idade de ${nome} é ${idade}`;
}

function mostraCidade(nome, cidade) {
  return `A cidade de ${nome} é ${cidade}`;
}

function mostraProfissao(nome, profissao) {
  return `A profissão de ${nome} é ${profissao}`;
}

export {mostraIdade, mostraCidade, mostraProfissao};