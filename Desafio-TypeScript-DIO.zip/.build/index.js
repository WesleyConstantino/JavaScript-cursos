var Trabalho;
(function(Trabalho2) {
  Trabalho2[Trabalho2["Atriz"] = 0] = "Atriz";
  Trabalho2[Trabalho2["Padeiro"] = 1] = "Padeiro";
})(Trabalho || (Trabalho = {}));
let pessoa1 = {
  nome: "maria",
  idade: 29,
  profissao: 0
};
let pessoa2 = {
  nome: "roberto",
  idade: 19,
  profissao: 1
};
let pessoa3 = {
  nome: "laura",
  idade: 32,
  profissao: 0
};
let pessoa4 = {
  nome: "carlos",
  idade: 19,
  profissao: 1
};
//# sourceMappingURL=index.js.map
